int16_t analogRead(uint8_t pin);

